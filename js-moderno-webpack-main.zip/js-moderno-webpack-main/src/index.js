import { saludar } from './js/componentes';
import './styles.css';

const nombre = 'Fernando';

saludar( nombre );
